library(readr)
library(dplyr)
library(ggplot2)

library(cowplot)
theme_set(theme_cowplot())

# this comes from https://github.com/rmcelreath/rethinking
fish <- read_csv2('Fish.csv') %>%
  mutate(hours = as.numeric(hours),
         camper = factor(camper, levels = 0:1, labels = c('Camper', 'Non-camper')))

table(fish$fish_caught)

pdf()
filter(fish, fish_caught > 0) %>%
  ggplot(aes(hours, fish_caught, color = camper)) +
  geom_point()
dev.off()
